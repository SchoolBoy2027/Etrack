import FormBuilder, { type FormInput } from "./lib/FormBuilder";

const expenseInputs: FormInput[] = [
    {
        name: "amount",
        label: "Amount",
        type: "text",
        required: true
    },
    {
        name: "expense_date",
        label: "Expense Date",
        type: "date",
        required: true
    },
    {
        name: "category",
        label: "Category",
        type: "select",
        required: true,
        options: [
            { label: "Food", value: "food" },
            { label: "Transportation", value: "transportation" },
            { label: "Utilities", value: "utilities" },
            { label: "Entertainment", value: "entertainment" }
        ]
    },
    {
        name: "description",
        label: "Description",
        type: "multiline"
    }
];

const ExpenseScreen = () => {
    const handleSubmit = (values: Record<string, string>) => {
        console.log("Expense:", values);
    };

    return (
        <FormBuilder
            inputs={expenseInputs}
            onSubmit={handleSubmit}
        />
    );
};

export default ExpenseScreen;