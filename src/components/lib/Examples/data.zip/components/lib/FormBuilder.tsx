
/*npx expo install expo-sqlite
npx expo install @react-native-community/datetimepicker
npx expo install @react-native-community/datetimepicker @react-native-picker/picker


FormBuilder.tsx
This component supports:
- text — Single-line text input.
- multiline — Multiline text input.
- date — Native date picker.
- select — Dropdown populated by an SQLite query.
- required — Displays a red asterisk and validates the field.
- onSubmit — Returns validated form values.
The query, primaryKey, and displayField properties determine how select options are populated.
*/

import React, { useState } from "react";

import {
    View,
    Text,
    TextInput,
    Pressable,
    Modal,
    FlatList,
    Platform,
    StyleSheet
} from "react-native";


import DateTimePicker, {
    type DateTimePickerEvent
} from "@react-native-community/datetimepicker";

export type SelectOption = {
    label: string;
    value: string;
};

export type FormInput = {
    name: string;
    label: string;
    type: "text" | "multiline" | "date" | "select" | "currency" | "integer";
    required?: boolean;
    options?: SelectOption[];
};

type FormBuilderProps = {
    inputs: FormInput[];
    onSubmit: (values: Record<string, string>) => void;
    initialValues?: Record<string, string>;
};

const FormBuilder = ({
    inputs,
    onSubmit,
    initialValues = {}
}: FormBuilderProps) => {

    const [values, setValues] =
        useState<Record<string, string>>(initialValues);

    const [errors, setErrors] =
        useState<Record<string, string>>({});

    const [activeSelect, setActiveSelect] =
        useState<string | null>(null);

    const [activeDate, setActiveDate] =
        useState<string | null>(null);

    const handleChange = (name: string, value: string) => {
        setValues((previous) => ({
            ...previous,
            [name]: value
        }));

        setErrors((previous) => ({
            ...previous,
            [name]: ""
        }));
    };

    const formatDate = (date: Date): string => {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const day = String(date.getDate()).padStart(2, "0");

        return `${year}-${month}-${day}`;
    };

    const getDate = (value: string): Date => {
        if (value) {
            const parts = value.split("-");

            if (parts.length === 3) {
                const year = Number(parts[0]);
                const month = Number(parts[1]);
                const day = Number(parts[2]);
                const date = new Date(year, month - 1, day);

                if (
                    date.getFullYear() === year &&
                    date.getMonth() === month - 1 &&
                    date.getDate() === day
                ) {
                    return date;
                }
            }
        }

        return new Date();
    };

    const handleDateChange = (
        event: DateTimePickerEvent,
        selectedDate?: Date
    ) => {
        if (Platform.OS === "android") {
            const fieldName = activeDate;
            setActiveDate(null);

            if (
                event.type === "set" &&
                selectedDate &&
                fieldName
            ) {
                handleChange(fieldName, formatDate(selectedDate));
            }
        } else {
            if (
                event.type === "set" &&
                selectedDate &&
                activeDate
            ) {
                handleChange(activeDate, formatDate(selectedDate));
            }
        }
    };

    const validateForm = (): boolean => {
        const newErrors: Record<string, string> = {};
        let valid = true;

        inputs.forEach((input) => {
            const value = values[input.name] || "";

            if (input.required && value.trim() === "") {
                newErrors[input.name] = `${input.label} is required`;
                valid = false;
            }

            if (input.type === "currency" && value.trim() !== "") {
                if (!/^\d+(\.\d{1,2})?$/.test(value)) {
                    newErrors[input.name] = "Enter a valid currency amount";
                    valid = false;
                }
            }

            if (input.type === "integer" && value.trim() !== "") {
                if (!/^\d+$/.test(value)) {
                    newErrors[input.name] = "Enter a valid whole number";
                    valid = false;
                }
            }

            if (input.type === "date" && value.trim() !== "") {
                const date = getDate(value);

                if (formatDate(date) !== value) {
                    newErrors[input.name] = "Invalid date";
                    valid = false;
                }
            }

            if (input.type === "select" && value !== "") {
                const exists = (input.options || []).some(
                    (option) => option.value === value
                );

                if (!exists) {
                    newErrors[input.name] = "Invalid selection";
                    valid = false;
                }
            }
        });

        setErrors(newErrors);
        return valid;
    };

    const handleSubmit = () => {
        if (validateForm()) {
            onSubmit(values);
        }
    };

    const renderInput = (input: FormInput) => {
        const value = values[input.name] || "";

        switch (input.type) {
            case "text":
                return (
                    <TextInput
                        style={styles.input}
                        value={value}
                        onChangeText={(text) =>
                            handleChange(input.name, text)
                        }
                    />
                );

            case "multiline":
                return (
                    <TextInput
                        style={[styles.input, styles.multiline]}
                        value={value}
                        multiline={true}
                        textAlignVertical="top"
                        onChangeText={(text) =>
                            handleChange(input.name, text)
                        }
                    />
                );

            case "currency":
                return (
                    <TextInput
                        style={styles.input}
                        value={value}
                        keyboardType="decimal-pad"
                        placeholder="0.00"
                        onChangeText={(text) =>
                            handleChange(input.name, text)
                        }
                    />
                );

            case "integer":
                return (
                    <TextInput
                        style={styles.input}
                        value={value}
                        keyboardType="number-pad"
                        placeholder="0"
                        onChangeText={(text) =>
                            handleChange(input.name, text)
                        }
                    />
                );

            case "date":
                return (
                    <View>
                        <Pressable
                            style={styles.input}
                            onPress={() => setActiveDate(input.name)}
                        >
                            <Text>
                                {value || "Select a date"}
                            </Text>
                        </Pressable>

                        {activeDate === input.name && (
                            <View>
                                <DateTimePicker
                                    value={getDate(value)}
                                    mode="date"
                                    display="default"
                                    onChange={handleDateChange}
                                />

                                {Platform.OS === "ios" && (
                                    <Pressable
                                        style={styles.button}
                                        onPress={() => setActiveDate(null)}
                                    >
                                        <Text style={styles.buttonText}>
                                            Done
                                        </Text>
                                    </Pressable>
                                )}
                            </View>
                        )}
                    </View>
                );

            case "select":
                return (
                    <View>
                        <Pressable
                            style={styles.input}
                            onPress={() => setActiveSelect(input.name)}
                        >
                            <Text>
                                {input.options?.find(
                                    (option) => option.value === value
                                )?.label || "Select an option"}
                            </Text>
                        </Pressable>

                        <Modal
                            visible={activeSelect === input.name}
                            transparent={true}
                            animationType="slide"
                            onRequestClose={() => setActiveSelect(null)}
                        >
                            <View style={styles.modalContainer}>
                                <View style={styles.modalContent}>
                                    <FlatList
                                        data={input.options || []}
                                        keyExtractor={(item) => item.value}
                                        renderItem={({ item }) => (
                                            <Pressable
                                                style={styles.option}
                                                onPress={() => {
                                                    handleChange(
                                                        input.name,
                                                        item.value
                                                    );
                                                    setActiveSelect(null);
                                                }}
                                            >
                                                <Text>{item.label}</Text>
                                            </Pressable>
                                        )}
                                    />

                                    <Pressable
                                        style={styles.button}
                                        onPress={() => setActiveSelect(null)}
                                    >
                                        <Text style={styles.buttonText}>
                                            Cancel
                                        </Text>
                                    </Pressable>
                                </View>
                            </View>
                        </Modal>
                    </View>
                );
        }
    };

    return (
        <View style={styles.container}>
            {inputs.map((input) => (
                <View key={input.name} style={styles.field}>
                    <Text style={styles.label}>
                        {input.label}
                        {input.required && (
                            <Text style={styles.required}> *</Text>
                        )}
                    </Text>

                    {renderInput(input)}

                    {errors[input.name] && (
                        <Text style={styles.error}>
                            {errors[input.name]}
                        </Text>
                    )}
                </View>
            ))}

            <Pressable style={styles.button} onPress={handleSubmit}>
                <Text style={styles.buttonText}>Submit</Text>
            </Pressable>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        padding: 16
    },
    field: {
        marginBottom: 15
    },
    label: {
        fontSize: 16,
        marginBottom: 5
    },
    required: {
        color: "red"
    },
    input: {
        borderWidth: 1,
        borderColor: "#777",
        borderRadius: 5,
        padding: 10,
        fontSize: 16,
        minHeight: 45
    },
    multiline: {
        minHeight: 100
    },
    error: {
        color: "red",
        marginTop: 5
    },
    button: {
        backgroundColor: "#333",
        padding: 12,
        borderRadius: 5,
        alignItems: "center"
    },
    buttonText: {
        color: "white",
        fontSize: 16
    },
    modalContainer: {
        flex: 1,
        justifyContent: "center",
        backgroundColor: "rgba(0,0,0,0.5)",
        padding: 25
    },
    modalContent: {
        backgroundColor: "white",
        borderRadius: 10,
        padding: 15,
        maxHeight: "70%"
    },
    option: {
        padding: 15,
        borderBottomWidth: 1,
        borderBottomColor: "#ddd"
    }
});

export default FormBuilder;
